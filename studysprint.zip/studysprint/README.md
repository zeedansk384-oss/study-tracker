# StudySprint – University Syllabus Milestone Tracker & Daily Study Timetable Planner

A front-end web app for 1st-year B.Tech students: enter subjects, chapters, exam dates and study hours, and it generates a balanced daily timetable, tracks completion and rebalances missed work.

## Run
Open `index.html` in any modern browser (double-click). No install or server needed.
Optional local server: `python -m http.server 8000` then open http://localhost:8000

## Features
- Onboarding, dashboard, today's plan, smart timetable, calendar, subjects (add/edit/delete), syllabus, analytics, settings
- Priority = exam urgency + difficulty + remaining work + revision requirement
- Revision, practice and final-revision slots; customizable study/break lengths
- Skip Today with automatic rebalancing
- Light/dark theme, mobile bottom navigation
- Data saved in browser localStorage (no backend)

## Deploy
Upload the folder to GitHub Pages, Netlify or Vercel as a static site.
